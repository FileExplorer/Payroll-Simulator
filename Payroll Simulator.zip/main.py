'''
Name: Yi Yang
Purpose: A program that allows the user to add, remove, and update information about employees
'''

from LinkedList import *
from Node import *
from Employee import *
import sys


def options():
    print('\n*** Payroll Simulator ***')
    print('a. Add New Employee')
    print('b. Enter Hours Worked')
    print('c. Display Payroll')
    print('d. Update Employee Hourly Rate')
    print('e. Remove Employee from Payroll')
    print('f. Exit the program')

allEmployees = LinkedList()

if __name__ == "__main__":
    options()
    userInput = input('Enter your choice: ')

    while userInput.lower() != 'f':
        if userInput == 'a':
            enterID = input('Enter the new employee ID: ')
            enterRate = input('Enter the hourly rate: ')
            #checks if ID is a number
            while not enterID.isnumeric():
                print('The new employee ID must be in digits!')
                enterID = input('Enter the new employee ID: ')
            #checks if rate is a number
            while not enterRate.isnumeric():
                print('The hourly rate must be in digits and $6 minimum!')
                enterRate = input('Enter the hourly rate: ')
            #checks if rate is greater than 6
            while int(enterRate) < 6:
                enterRate = input('The hourly rate must be $6 minimum! Enter a new digit: ')
            #if list is empty, just append, if not go traverse through list
            if allEmployees.isEmpty():
                allEmployees.append(Employee(enterID, enterRate))
            else:
                for i in range(allEmployees.__len__()):
                    #if node id is the same as entered ID, give error
                    while allEmployees.__getitem__(i).get_id() == enterID:
                        enterID = input('ID is already registered! Enter a new employee ID: ')
                    allEmployees.append(Employee(enterID, enterRate))
        elif userInput == 'b':
            if allEmployees.isEmpty():
                print('There are no employees')
            else:
                print('Here is the employee list:')
                #traverse the list
                for i in range(allEmployees.__len__()):
                    print(allEmployees.__getitem__(i).get_id())
                enterID = input('Which employee ID do you want to update hours for? ')
                enterHours = input('How many hours has %s worked? ' %enterID)
                while not enterID.isdigit():
                    enterID = input('ID must be in digits! Enter again: ')
                #makes sure hours worked is greater than 0
                while not int(enterHours) >= 0:
                    enterHours = input('enterHours must be greater than 0! Enter again: ')
                while not enterHours.isdigit:
                    enterHours = input('Hours must be in digits! Enter again: ')
                #updates time for employee node
                for i in range(allEmployees.__len__()):
                    if allEmployees.__getitem__(i).get_id() == enterID:
                        allEmployees.__getitem__(i).set_time(enterHours)
        elif userInput == 'c':
            if allEmployees.isEmpty():
                print('There are no employees to show a payroll for.')
            else:
                #traverses nodes and prints the data within them
                for i in range(allEmployees.__len__()):
                    print('ID: %s' %allEmployees.__getitem__(i).get_id())
                    print('Hours worked: %s' %allEmployees.__getitem__(i).get_time())
                    print('Pay rate: $ %s' %allEmployees.__getitem__(i).get_rate())
                    allEmployees.__getitem__(i).set_wage(allEmployees.__getitem__(i).get_time() * allEmployees.__getitem__(i).get_rate())
                    print('Gross wages: $ %s\n-' %allEmployees.__getitem__(i).get_wage())
        elif userInput == 'd':
            if allEmployees.isEmpty():
                print('There are no employees.')
            else:
                print('Here is the employee list:')
                for i in range(allEmployees.__len__()):
                    print(allEmployees.__getitem__(i).get_id())
                enterID = input('Enter the employee ID you wish to update hourly rate for: ')
                for i in range(allEmployees.__len__()):
                    if allEmployees.__getitem__(i).get_id() == enterID:
                        enterRate = input('Enter the new hourly rate: ')
                        while not enterRate.isdigit():
                            enterRate = input('Hourly rate must be in digits!')
                        while int(enterRate) <= 6:
                            enterRate = input('The hourly rate must be $6 minimum! Enter a new digit: ')
                        allEmployees.__getitem__(i).set_rate(enterRate)
        elif userInput == 'e':
            if allEmployees.isEmpty():
                print('There are no employees.')
            else:
                for i in range(allEmployees.__len__()):
                    print(allEmployees.__getitem__(i).get_id())
                    enterID = input('Enter the employee ID you wish to remove: ')
                    for i in range(allEmployees.__len__()):
                        if allEmployees.__getitem__(i).get_id() == enterID:
                            allEmployees.remove(allEmployees.__getitem__(i))
        options()
        userInput = input('Enter your choice: ')
    print('Goodbye')
    sys.exit()