'''
Name: Yi Yang
Purpose: a class that stores information about the employee for the main program
'''

class Employee():
    def __init__(self, id, rate, time = 0, wage = 0):
        self.__id = id
        self.__time = time
        self.__rate = rate
        self.__wage = self.__rate * self.__time

    def get_id(self):
        return self.__id

    def get_time(self):
        return self.__time

    def get_rate(self):
        return float(self.__rate)

    def set_time(self, newTime):
        self.__time = float(newTime)

    def set_rate(self, newRate):
        self.__rate = float(newRate)

    def set_wage(self, newWage):
        self.__wage = newWage

    def get_wage(self):
        return self.__wage
